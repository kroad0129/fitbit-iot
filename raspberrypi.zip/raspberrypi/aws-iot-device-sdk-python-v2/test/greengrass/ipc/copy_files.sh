cp ../../../samples/ipc_greengrass.py .
cp ../../../utils/run_in_ci.py .
cp ../../../.github/workflows/ci_run_greengrass_ipc_cfg.json .
